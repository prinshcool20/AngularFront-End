export class Customer {
    
  
		 accountId:any;
		
		 mobileno:any;

	
		holdername:any;

		
		 balance:any;

		
		 
}
