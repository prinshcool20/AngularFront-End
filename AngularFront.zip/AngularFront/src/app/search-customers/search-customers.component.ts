import { Component, OnInit, Input } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'search-customers',
  templateUrl: './search-customers.component.html',
  styleUrls: ['./search-customers.component.css']
})
export class SearchCustomersComponent implements OnInit {
  @Input() customer: Customer;
  mobileno: any;
  customers: Customer[];
  status = false;
  

  constructor(private dataService: CustomerService) { }

  ngOnInit() {
    this.mobileno = 0;
  }

  private searchCustomers() {
    this.dataService.getCustomersByMobile(this.mobileno)
      .subscribe(customers => this.customers = customers);
  }

  onSubmit() {
    this.searchCustomers();
  }
  
  onUpdate(){
    this.status = true;
  }

  deleteCustomer() {
      this.dataService.deleteCustomer(this.customer.accountId)
        .subscribe(
          data => {
            console.log(data);
           //this.listComponent.reloadData();
          },
          error => console.log(error));
    }

     updateCustomer() {
    this.dataService.updateCustomer(this.customer. accountId,
      { mobileno: this.customer.mobileno, holdername: this.customer.holdername,balance:this.customer.balance })
      .subscribe(
        data => {
          console.log(data);
          this.customer = data as Customer;
        },
        error => console.log(error));
        this.status = false;
  }
}
